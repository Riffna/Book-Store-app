package com.riffna.bookriot.model;

public class UserModel {
    String used_name;
    String used_email;
    String used_phone;
    String used_password;

    public String getUsed_name() {
        return used_name;
    }

    public void setUsed_name(String used_name) {
        this.used_name = used_name;
    }

    public String getUsed_email() {
        return used_email;
    }

    public void setUsed_email(String used_email) {
        this.used_email = used_email;
    }

    public String getUsed_phone() {
        return used_phone;
    }

    public void setUsed_phone(String used_phone) {
        this.used_phone = used_phone;
    }

    public String getUsed_password() {
        return used_password;
    }

    public void setUsed_password(String used_password) {
        this.used_password = used_password;
    }

    public UserModel(){}
}